#!/usr/bin/env ruby
#encoding:utf-8

module Tests

# Class to make the tests
class TestP3
		def self.main
				puts "It works!"
		end
end

# Launching the tests
TestP3.main()

end # module Tests
