# Author:
#   Sergio Quijano Rey

require_relative "../lib/SpaceStationToUI.rb"
require_relative "../lib/SuppliesPackage.rb"
require_relative "../lib/ShotResult.rb"
require_relative "../lib/CardDealer.rb"

module Deepspace

class SpaceStation
        # Class atributes
        #=======================================================================
        @@MAXFUEL = 100                 # Max fuel quantity that a space station can have
        @SHIELDLOSSPERUNITSHOT = 0.1    # Shield units lost per each shot unit taken

        # Initializers
        #=======================================================================
        
        # Description:
        #   Initializer of the class
        # Parameters:
        #   _name: String, name of the SpaceStation
        #   _supplies: SuppliesPackage, starting fuel units, weapons and shields
        def initialize(_name, _supplies)
                # Name is set
                @name = _name           # String

                # Rest of attributes are set
                @ammoPower = 0.0        # Float
                @fuelUnits = 0.0        # Float
                @nMedals = 0            # Integer
                @shieldPower = 0.0      # Float
                @pendingDamage = nil    # Damage
                @weapons = []           # Weapon[]
                @shieldBoosters = []    # ShieldBooster[]
                @hangar = nil           # Hangar
                
                # Supplies are added
                receiveSupplies(_supplies)
        end

        # Getters
        #=======================================================================

        # Attribute readers
        attr_reader :ammoPower, :fuelUnits, :hangar, :name, :nMedals, :pendingDamage, :shieldBoosters, :shieldPower, :weapons

        # Description:
        #   Gets the speed of the SpaceStation
        #   Speed is calculated as fraction of fuel units and max fuel possible
        # Returns:
        #   Float: percentage of speed, that's to say, a number in [0, 1]
        def speed
                if @@MAXFUEL == 0
                        puts "WARNING, zero division at SpaceStation.speed()"
                        return 0
                else
                        return @fuelUnits / @@MAXFUEL
                end
        end

        # Description:
        #   Checks the state of SpaceShip
        #   Valid state means no pending damage or pending damage with no effect
        # Returns:
        #   Boolean,    true, if SpaceShip is on valid state
        #               false, otherwise
        def validState
                if @pendingDamage.nil?
                        return true
                elsif @pendingDamage.length == 0 
                        return true
                elsif @pendingDamage.hasNoEffect
                        return true
                else
                        return false
                end
        end

        # Description
        #   Gets UI representation of the object
        # Returns
        #   SpaceStationToUI, the UI representation
        def getUIVersion
                if validState
                        return SpaceStationToUI.new(self)
                else
                        puts "WARNING! Not UI version for space station on invalid state"
                        return nil
                end
        end

        def to_s
                return "Space Station
                \tname: #{@name}
                \tammoPower: #{@ammoPower}
                \tfuelUnits: #{@fuelUnits}
                \tnmedals: #{@nMedals}
                \tshieldPower: #{@shieldPower}
                \tpendingDamage: #{@pendingDamage}
                \tweapons: #{@weapons}
                \tshieldBoosters: #{@shieldBoosters}
                \thangar: #{@hangar}"
        end
        
        # Setters
        #=======================================================================

        # Description:
        #   Assigns the fuel of the space station
        #   Private method
        # Parameters:
        #   f: Float
        def assignFuelValue(f)
                if f < @@MAXFUEL
                        @fuelUnits = f
                else
                        @fuelUnits = @@MAXFUEL
                end
        end

        # Description:
        #   Certain damage is adjusted to weapon list and shieldBoosters and it's
        #   value is stored in the object
        # Parameters:
        #   d: Damage, the damage to set
        def setPendingDamage(d)
                if d.weapons.length != 0
                        @pendingDamage = @pendingDamage.adjust(d.weapons, d.nShields)
                else
                        @pendingDamage = @pendingDamage.adjust(Array.new(d.nWeapons, d.nShields))
                end
        end

        # Description:
        #   If pending damage has no effect, fixes the atribute to nil
        def cleanPendingDamage
                if @pendingDamage.hasNoEffect
                        @pendingDamage = nil
                end
        end

        # Description:
        #   Tries to add a weapon to the hangar
        # Parameters:
        #   w: Weawpon, the weapon to add
        # Returns:
        #   Boolean:    true, if weapon is succesfully added
        #               false, if weapon fails to be added
        def receiveWeapon(w)
                if @hangar.nil? != false
                        return @hangar.addWeapon(w)
                else
                        puts "Warning! No hangar where to put the weapon"
                        return false
                end
        end

        # Description:
        #   Tries to add a shield booster
        # Parameters:
        #   s: ShieldBooster, the shield we are trying to add
        # Returns:
        #   Boolean:    true, if shield is succesfully added
        #               false, if shield fails to be added
        def receiveShieldBooster(s)
                if @hangar.nil? != false
                        return @hangar.addShieldBooster(s)
                else
                        puts "Warning! No hangar where to put the shield"
                        return false
                end
        end

        # Description:
        #   Tries to add an hangar
        #   If there's already an hangar, this method has no effect
        # Parameters:
        #   h: Hangar, the hangar to add
        def receiveHangar(h)
                if @hangar.nil? 
                        @hangar = Hangar.newCopy(h) # Security copy
                end
        end

        # Description:
        #   Discards current hangar (nil reference)
        def discardHangar
                @hangar = nil
        end

        # Description:
        #   If hangar is available, discars a weapon from it
        # Parameters:
        #   i: Integer, index of the weapon at hangar to discard
        def discardShieldBoosterInHangar(i)
                if @hangar.nil? == false
                        @hangar.removeShieldBooster(i)
                else
                        puts "WARNING! Trying to discard a weapon where no hangar is available, at SpaceStation.discardShieldBoosterInHangar()"
                end
        end

        # Description:
        #   Shoot, shield and fuel power increase by a certain SuppliesPackage
        # Parameters:
        #   s: SuppliesPackage, the supplies to add
        def receiveSupplies(s)
                @ammoPower = @ammoPower + s.ammoPower
                @fuelUnits = @fuelUnits + s.fuelUnits
                @shieldPower = @shieldPower + s.shieldPower
        end

        # Description:
        #   A weapon from the hangar is mounted to be used
        #   If method runs succesfully, weapon is erased from Hangar, and the weapon
        #   is added to the collection of weapons in use
        # Parameters:
        #   i: Integer, index of the weawpon to mount
        def mountWeapon(i)
                if @hangar.nil?
                        puts "WARNING! No hangar available at SpaceStation.mountWeapon()"
                else
                        # New weapon is deleted from the hangar
                        new_weapon = @hangar.removeWeapon(i) 
                        if new_weapon.nil? == false
                                @weapons << new_weapon
                        else
                                puts "WARNING! Trying to add nil weapon on SpaceStation.mountWeapon()"
                        end
                end
        end

        # Description:
        #   A ShieldBooster from the hangar is mounted
        #   If method runs succesfully, shield is removed from Hangar, and that shield
        #   is added to collection of shields in use
        # Parameters:
        #   i: Integer, position of the shield to mount
        def mountShieldBooster(i)
                if @hangar.nil?
                        puts "WARNING! No hangar available, at SpaceStation.mountShieldBooster()"
                else
                        new_shield = @hangar.removeShieldBooster(i)
                        if new_shield.nil?
                                puts "WARNING! Trying to add nil shield on Spacestation.mountShieldBooster()"
                        else
                                @shieldBoosters << new_shield
                        end
                end
        end

        # Description:
        #   The spaceships moves. Therefore, fuel units decrease
        def move
                @fuelUnits = @fuelUnits * (1-speed)
        end

        # Description:
        #   Deletes all mounted weapons and mounted shields with no uses left
        def cleanUpMountedItems
                # Filtering weapons
                @weapons = @weapons.select{|weapon|  weapon.uses > 0}

                # Filtering shields
                @shieldBoosters = @shieldBoosters.select{|shield| shield.uses > 0}
        end

        # Description:
        #   Makes a shoot, this method determines the power of the shoot
        # Returns:
        #   Float,  the shoot power, product of all weaponBoosters times ammoPower, if there are weapons
        #           ammoPower, if there are no weapons
        def fire
            if @weapons.nil?
                return @ammoPower
            else
                factor = 1

                for weapon in @weapons
                    factor = factor * weapon.useIt()
                end
                
                return factor * @ammoPower

            end
        end
        
        # Description:
        #   The shield is used
        # Returns:
        #   Float,  shieldPower times the product of all shieldBoosters, if there are shields
        #           shieldPower, if there are not shields
        def protection
            if @shieldsBoosters.nil?
                return @shieldPower
            else
                factor = 1
                for shield in @shieldBoosters
                    factor = factor * shield.useIt
                end

                return factor * @shieldPower
            end
        end

        # Description:
        #   The space station receives a shot
        # Parameters:
        #   shot: Float, the power of the received shot
        # Returns:
        #   ShotResult, ShotResult::RESIST if the space station resists
        #               ShotResult::DONOTRESIST, otherwise
        def receiveShot(shot)
            myProtection = protection

            if myProtection < shot
                # We don't resist the shot, therefore the shield is broken
                @shieldPower = 0.0

                return ShotResult::DONOTRESIST
            else
                # The shot is resisted, therefore the shieldPower is decreased
                @shieldPower = @shieldPower - SHIELDLOSSPERUNITSHOT * shot
                @shieldPower = [@shieldPower, 0.0].max

                return ShotResult::RESIST
            end
        end

        # Description:
        #   The space station receives a loot
        #   ShieldBoosters, WeaponsBoosters and Medals are increased as specified by the loot
        #   They depend also on CardDealer action
        # Parameters:
        #   loot: Loot, the loot received
        def setLoot(loot)
            # We get the single instance of the CardDealer
            dealer = CardDealer.getInstance
            
            # We get the hangars of the loot
            if loot.getNHangars
                # The CardDealer gives us an hangar
                hangar = dealer.nextHangar()

                # We add the hangar
                receiveHangar(hangar)
            end

            # We get the supplies of the loot
            loot.getNSupplies.times do
                # The card dealer gives us a suppliesPackage
                sup = dealer.nextSuppliesPackage

                # We add the supplies package
                receiveSupplies(sup)
            end

            # We get the weapons of the loot
            loot.getNWeapons.times do
                # The card dealer gives us a weapon
                wep = dealer.nextWeapon()

                # We add the weapon
                receiveWeapon(wep)
            end

            # We get the shield boosters of the loot
            loot.getNShields.times do
                # The card dealer gives us a shieldBooster
                sh = dealer.nextShieldBooster

                # We add the shieldBooster
                receiveShieldBoostert(sh)
            end

            # We get the medals of the loot
            @nMedals = @nMedals + loot.getNMedals
        end

        # Description:
        #   A weapon is discarded from the space station
        # Parameters:
        #   i: Integer, the position of the weapon to be discarded
        def discardWeapon(i)
            if i < 0 or i >= @weapons.size
                puts "WARNING! You used SpaceStation.discardWeapon() on invalid position!"
                puts "Nothing is done"
            else
                # The weapon is deleted from set of weapons
                w = @weapons.remove(i)

                if @pendingDamage.nil? == false
                    # We weapon is discarded from pending damage
                    @pendingDamage.discardWeapon(w)

                    # The pending damage is cleaned
                    cleanPendingDamage()
                end
            end
        end

        # Description:
        #   A shieldBooster is discarded from the space station
        # Parameters:
        #   i: Integer, the position of the shieldBooster to be discarded
        def discardShieldBooster
            if i < 0 or i >= @shieldBoosters.size
                puts "WARNING! You used SpaceStation.discardShieldBooster() on invalid position!"
                puts "Nothing is done"
            else
                # The shieldBooster is deleted from set of shieldBoosters
                s = @shieldBooster.remove(i)

                if @pendingDamage.nil? == false
                    # We shieldBooster is discarded from pending damage
                    @pendingDamage.discardShieldBooster(s)

                    # The pending damage is cleaned
                    cleanPendingDamage()
                end
            end
        end

        # Private Specifiers
        #=======================================================================
        private :assignFuelValue, :cleanPendingDamage
end

end # Deepspace
