#encoding:utf-8

module Deepspace

# Enum to represent the types of weapons available on the game
module WeaponType
	# Class to represent the types of weapons
	class Type
		# Description:
		# 	Initializer of the class
		# Parameters:	
		# 	_power: Float,representing the power of the weapon
		def initialize(_power)
			@POWER = _power
		end
		
		# Description:
		# 	Power getter
		# Return:
		# 	Float, containing the power of the weapon
		def power
			return @POWER
		end

		def to_s
				return "WeaponType(#{@name})"
		end
	end

	# Types of weapons available on our game
	LASER =		Type.new(2.0)
	MISSILE =	Type.new(3.0)
	PLASMA =	Type.new(4.0)
end

end # module Deepspace
