#encoding:utf-8

module Deepspace

# Enum to represent the result of a shot taken
module ShotResult
	DONOTRESIST=	:donotresist
	RESIST=			:resist
end

end # module Deepspace
