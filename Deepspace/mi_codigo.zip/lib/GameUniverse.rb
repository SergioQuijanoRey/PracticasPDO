#encoding:utf-8

# Author:
#   Sergio Quijano Rey

require_relative "../lib/GameStateController.rb"
require_relative "../lib/GameUniverseToUI.rb"
require_relative "../lib/Dice.rb"

module Deepspace

class GameUniverse
		# Class atributes
		#=======================================================================
		@@WIN = 10

		# Initializers
		#=======================================================================
		# Description:
		# 	Initializer of the class
		def initialize
				@gameState = GameStateController.new		# GameStateController
				@turns = 0									# Integer
				@dice = Dice.new							# Dice

				@currentStationIndex = nil					# Integer
				@currentStation = nil						# SpaceStation
				@spaceStations = nil						# SpaceStation[]
				@currentEnemy = nil							# EnemyStarShip
		end

		# Getters
		#=======================================================================
		def gameState
				return @gameState
		end

		# WIP -- Practica 3
		# Description:
		# Paramters:
		# 	station: SpaceStation
		# 	enemy: EnemyStarShip
		# Returns:
		# 	CombatResult
		def combatGo(station, enemy)
		end

		# WIP -- Practica 3
		# Description:
		# Returns:
		# 	CombatResult
		def combat()
		end

		# Description:
		# 	Gets the UI representation of the object
		# Returns:
		# 	GameUniverseToUI: the UI representation
		def getUIVersion
				return GameUniverseToUI.new(@currentStation, @currentEnemy)
		end

            # Description:
            # 	Checks if spaceShip which is on turn have won
            # Returns:
            # 	Boolean	true, if the space ship has won
            # 			false, otherwise
            def haveAWinner
                    if @currentStation.nil?
                            puts "Warning! @currentStation nil on GameUniverse.haveAWinner()"
                            return false
                    else
                            if @currentStation.nMedals >= @@WIN
                                    return true
                            else
                                    return false
                            end
                    end
            end

            def to_s
                    return "GameUniverse(#{@gameState}, #{@turns}, #{@dice})"
            end

            # Setters
            #=======================================================================
            
            # Description:
            # 	The current space station discards an Hangar if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            def discardHangar
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.discardHangar
                    end
            end

            # Description:
            # 	The current space station discards a shield Booster if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the shield booster to discard
            def discardShieldBooster(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.discardShieldBooster(i)
                    end
            end

            # Description:
            # 	The current space station discards a shield Booster in the Hangar if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the shield booster to discard
            def discardShieldBoosterInHangar(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.discardShieldBoosterInHangar(i)
                    end
            end

            # Description:
            # 	The current space station discards a weapon if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the weapon to discard
            def discardWeapon(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.discardWeapon(i)
                    end
            end

            # Description:
            # 	The current space station discards a weapon in the hangar if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the weapon to discard
            def discardWeaponInHangar(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.discardWeaponInHangar(i)
                    end
            end

            # Description:
            # 	The current space station mounts a shield booster if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the shield booster to mount
            def mountShieldBooster(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.mountShieldBooster(i)
                    end
            end

            # Description:
            # 	The current space station mounts a shield booster if GameState is INIT or AFTERCOMBAT
            # 	Otherwise, this method has no effect
            # Parameters:
            # 	i: Integer, position of the weapon to mount
            def mountWeapon(i)
                    if @gameState == GameState::INIT or GameState::AFTERCOMBAT
                            @currentStation.mountWeapon(i)
                    end
            end

            # WIP -- Practica 3
            # Description:
            # Returns:
            # 	Boolean
            def nexTurn
            end

            # Description:
            #   Starts the game
            #   For each given player, a space station is created, which is equipped with
            #   suppliesPackages, hangars, weapons and shieldBoosters
            #   The starting player is chosen
            #   The starting enemy is chosen
            #   The first turn is started
            # Parameters:
            # 	names: String[], the names of the players
            def init(names)
                # The current state of the game
                state = @gameState.state

                # Check if the game has not been initialized before
                if state == GameState::CANNOTPLAY
                    # New space stations are created from scratch
                    @spaceStations = []

                    # We get a dealer instance
                    dealer = CardDealer.instance

                    # Space stations are created for each player and added to the set of space stations
                    for name in names
                        # We get the supplies packages for the new space station
                        supplies = dealer.nextSuppliesPackage

                        # We create the station and add to the set of space stations
                        station = SpaceStation.new(name, supplies)
                        @spaceStations << station

                        # We get some random decisions from the dice, to create a starting loot
                        nh = @dice.initWithNHangars
                        nw = @dice.initWithNWeapons
                        ns = @dice.initWithNShields

                        # Starting loot is created
                        lo = Loot.new(0, nw, ws, nh, 0)

                        # We add the elements of the loot to the space station
                        # BUG -- Probablemente aqui pueda pasar que modifique station pero no el elemento de @spaceStations
                        station.setLoot(lo)
                    end


                    # The starting player is chosen
                    @currentStationIndex = @dice.whoStarts(names.size)
                    @currentStation = @spaceStations[@currentStationIndex]

                    # The starting enemy is chosen
                    @currentEnemy = dealer.nextEnemy

                    # We launch the starting turn (@turns is now 0)
                    @gameState.next(@turns, @spaceStations.size)
                end
        end
end

end # module Deepspace
